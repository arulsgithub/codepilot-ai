package com.codepilot.symbols.controller;

import com.codepilot.symbols.dto.FileQueryRequest;
import com.codepilot.symbols.dto.ImpactRequest;
import com.codepilot.symbols.dto.SymbolQueryRequest;
import com.codepilot.symbols.dto.SymbolQueryResponses.DependenciesResponse;
import com.codepilot.symbols.dto.SymbolQueryResponses.ImpactResponse;
import com.codepilot.symbols.dto.SymbolQueryResponses.UsagesResponse;
import com.codepilot.symbols.service.SymbolQueryService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * POST rather than GET for all three: the inputs are Windows paths and qualified names full of
 * backslashes, dots and '#', which are awkward and error-prone as query parameters.
 */
@RestController
@RequestMapping("/api/v1/symbols")
public class SymbolController {

    private final SymbolQueryService symbolQueryService;

    public SymbolController(SymbolQueryService symbolQueryService) {
        this.symbolQueryService = symbolQueryService;
    }

    /** "Where is this called from?" */
    @PostMapping("/usages")
    public ResponseEntity<UsagesResponse> usages(@Valid @RequestBody SymbolQueryRequest request) {
        return ResponseEntity.ok(
                symbolQueryService.findUsages(request.repositoryRoot(), request.symbol()));
    }

    /** "What does this file depend on?" */
    @PostMapping("/dependencies")
    public ResponseEntity<DependenciesResponse> dependencies(@Valid @RequestBody FileQueryRequest request) {
        return ResponseEntity.ok(
                symbolQueryService.findDependencies(request.repositoryRoot(), request.relativeFilePath()));
    }

    /** "What breaks if I change this?" */
    @PostMapping("/impact")
    public ResponseEntity<ImpactResponse> impact(@Valid @RequestBody ImpactRequest request) {
        return ResponseEntity.ok(symbolQueryService.findImpact(
                request.repositoryRoot(), request.symbol(), request.maxDepth()));
    }
}