package com.codepilot.symbols.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record ImpactRequest(

        @NotBlank(message = "repositoryRoot must not be blank")
        String repositoryRoot,

        @NotBlank(message = "symbol must not be blank")
        String symbol,

        /**
         * How many call-chain hops to follow. Null means the default (3).
         * Capped hard: each level multiplies the result set, and a real call graph fans out fast.
         */
        @Min(value = 1, message = "maxDepth must be at least 1")
        @Max(value = 5, message = "maxDepth must not exceed 5")
        Integer maxDepth
) {
}