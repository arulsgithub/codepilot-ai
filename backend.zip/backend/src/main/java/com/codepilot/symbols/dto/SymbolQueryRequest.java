package com.codepilot.symbols.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * `symbol` accepts three levels of precision, in decreasing order:
 *   com.codepilot.chat.service.ChatService#chat   (exact)
 *   ChatService#chat                              (type + member)
 *   chat                                          (bare name - may be ambiguous)
 */
public record SymbolQueryRequest(

        @NotBlank(message = "repositoryRoot must not be blank")
        String repositoryRoot,

        @NotBlank(message = "symbol must not be blank")
        String symbol
) {
}