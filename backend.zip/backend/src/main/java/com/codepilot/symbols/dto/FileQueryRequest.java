package com.codepilot.symbols.dto;

import jakarta.validation.constraints.NotBlank;

public record FileQueryRequest(

        @NotBlank(message = "repositoryRoot must not be blank")
        String repositoryRoot,

        @NotBlank(message = "relativeFilePath must not be blank")
        String relativeFilePath
) {
}